MD5
===
the implements of md5 using different lan, copyright@network.
